<?php $__env->startSection('meta'); ?>

    <title>HOME - MatteuSan</title>

    <!-- BASIC META -->
    <meta name="description" content="The official website of the Luwal Sining-Pagganap" />

    <!-- OPENGRAPH -->
    <meta property="og:title" content="Home - Luwal Sining-Pagganap" />
    <meta property="og:description" content="The official website of the Luwal Sining-Pagganap" />
    <meta property="og:image" content="https://luwal-sining.xyz/img/ogphoto.png" />

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>

    <section class="banner">
        <div class="wrap--text">
            <h1><?php echo __('HI! I\'M <u>MATTEU!</u>'); ?> </h1>
            <h5><?php echo e(__('I\'m a frontend developer, composer, arranger, orchestrator and music copyist')); ?></h5>

            <div class="banner__socials">
                <a href="https://twitter.com/InvestmentGt" target="_blank">
                    <i class="banner__icon fab fa-twitter-square"></i>
                </a>
                <a href="https://instagram.com/investment.gt" target="_blank">
                    <i class="banner__icon fab fa-instagram"></i>
                </a>
                <a href="https://patreon.com/growstocks" target="_blank">
                    <i class="banner__icon fab fa-patreon"></i>
                </a>
            </div>

        </div>
    </section>

    <section class="wrap--content--no-margin-top">

        <h2 class="title-bar--on-surface"><?php echo e(__('WEBSITES/WEBAPPS I\'VE BEEN WORKING ON')); ?></h2>
        <div class="card--on-surface">
            <p><?php echo e(__('Here\'s a complete list of all the websites/webapps I\'ve been developing/developing with a few friends in my spare time and in my coding time.')); ?></p>
        </div>

        <div class="container--grid">
            <?php if (isset($component)) { $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardY::class, ['title' => 'GrowStocks','subtitle' => 'Growtopia\'s Online Price Checker and tech solutions','image' => 'img/growstocks.jpg','to' => 'https://growstocks.xyz']); ?>
<?php $component->withName('card-y'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411)): ?>
<?php $component = $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411; ?>
<?php unset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardY::class, ['title' => 'BlockCorp','subtitle' => 'The platform to order Growtopia-related services','image' => 'img/blockcorp.jpg','to' => 'https://blockcorp.xyz']); ?>
<?php $component->withName('card-y'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411)): ?>
<?php $component = $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411; ?>
<?php unset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardY::class, ['title' => 'Purple Cress','subtitle' => 'Purple Cress Scanlation\'s manga reader','image' => 'img/purplecress.jpg','to' => 'https://purple-cress-manga-reader.web.app/']); ?>
<?php $component->withName('card-y'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411)): ?>
<?php $component = $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411; ?>
<?php unset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardY::class, ['title' => 'Luwal Sining-Pagganap','subtitle' => 'LSP\'s main website and performance platform','image' => 'img/luwal.jpg','to' => 'https://luwal-sining.xyz']); ?>
<?php $component->withName('card-y'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411)): ?>
<?php $component = $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411; ?>
<?php unset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            <?php if (isset($component)) { $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\CardY::class, ['title' => 'Stack: A Frontend Library','subtitle' => 'GrowStocks\' proprietary frontend library for building UIs efficiently','image' => 'img/stack.jpg','to' => 'https://github.com/GrowStocks/stack']); ?>
<?php $component->withName('card-y'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411)): ?>
<?php $component = $__componentOriginal150f609a500525ba56edd979119e5b6b24d13411; ?>
<?php unset($__componentOriginal150f609a500525ba56edd979119e5b6b24d13411); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
        </div>

    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\matteusan\resources\views/main/home.blade.php ENDPATH**/ ?>