<!doctype html>
<html
    lang="<?php echo e(App::getLocale()); ?>"
    x-data="{}"
>
<head>

    <?php echo $__env->yieldContent('meta'); ?>

    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <!-- CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('css/stack/style.css')); ?>">
    <link rel="stylesheet" href="https://unpkg.com/material-components-web@11.0.0/dist/material-components-web.css">

    <!-- JS -->
    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.8.2/dist/alpine.min.js"></script>

    <!-- ICONS -->
    <link href="https://fonts.googleapis.com/css?family=Material+Icons|Material+Icons+Outlined|Material+Icons+Two+Tone|Material+Icons+Round|Material+Icons+Sharp" rel="stylesheet">
    <script src="https://kit.fontawesome.com/0fb562e3a8.js" crossorigin="anonymous"></script>

    <!-- VIEWPORT -->
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">

    <!-- OPENGRAPH -->
    <meta property="og:image" content="">
    <meta property="og:type" content="website">
    <meta property="og:title" content="MatteuSan">

    <!-- FAVICON -->
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo e(asset('img/favicon.ico')); ?>">
    <link rel="icon" type="img/png" sizes="32x32" href="<?php echo e(asset('img/favicon.ico')); ?>">
    <link rel="icon" type="img/png" sizes="16x16" href="<?php echo e(asset('img/favicon.ico')); ?>">

    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<header class="header">

    <div class="header__wrap">

        <div class="header__text">
            <a href="<?php echo e(route('home', App::getLocale())); ?>">
                <h2>MatteuSan</h2>
            </a>
        </div>

        <div class="nav">

            <div class="nav__container">

                <div class="nav__item">
                    <a class="nav__item_icon <?php echo e(Request::segment(2) == "" ? 'material-icons' : 'material-icons-outlined'); ?>" title="<?php echo e(__('Home')); ?>" data-mdc-ripple-is-unbounded="true" href="<?php echo e(route('home', App::getLocale())); ?>">home</a>
                    <p class="nav__item_text"><?php echo e(__('Home')); ?></p>
                </div>

                <div class="nav__item">
                    <a class="nav__item_icon <?php echo e(Request::segment(2) == "bio" ? 'material-icons' : 'material-icons-outlined'); ?>" title="<?php echo e(__('Bio')); ?>" data-mdc-ripple-is-unbounded="true" href="<?php echo e(route('bio', App::getLocale())); ?>">face</a>
                    <p class="nav__item_text"><?php echo e(__('About Me')); ?></p>
                </div>

                <div class="nav__item">
                    <a class="nav__item_icon <?php echo e(Request::segment(2) == "music" ? 'material-icons' : 'material-icons-outlined'); ?>" title="<?php echo e(__('Music')); ?>" data-mdc-ripple-is-unbounded="true" href="<?php echo e(route('music', App::getLocale())); ?>">piano</a>
                    <p class="nav__item_text"><?php echo e(__('Music')); ?></p>
                </div>

                <div class="nav__item nav__item--more">
                    <a class="nav__item_icon <?php echo e(Request::segment(2) == "webdev" ? 'material-icons' : 'material-icons-outlined'); ?>" title="<?php echo e(__('Music')); ?>" data-mdc-ripple-is-unbounded="true" href="<?php echo e(route('webdev', App::getLocale())); ?>">web</a>
                    <p class="nav__item_text"><?php echo e(__('Web Dev')); ?></p>
                </div>

            </div>

        </div>

    </div>

</header>

<body>

<?php echo $__env->yieldContent('contents'); ?>

<?php echo \Livewire\Livewire::scripts(); ?>

<script type="text/javascript" src="<?php echo e(asset('js/index.js')); ?>"></script>
</body>

<footer class="footer">
    <div class="wrap--text">
        <h3>@MatteuSan</h3>
        <h5><?php echo __('Copyright '. date('Y') .' &copy; MatteuSan'); ?></h5>
    </div>
    <div class="footer__language__wrap">
        <?php if (isset($component)) { $__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Language::class, ['code' => 'en','language' => 'English']); ?>
<?php $component->withName('language'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83)): ?>
<?php $component = $__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83; ?>
<?php unset($__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        <span class="footer__language__spacer">|</span>

        <?php if (isset($component)) { $__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Language::class, ['code' => 'tl','language' => 'Tagalog']); ?>
<?php $component->withName('language'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83)): ?>
<?php $component = $__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83; ?>
<?php unset($__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>

        <span class="footer__language__spacer">|</span>

        <?php if (isset($component)) { $__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Language::class, ['code' => 'ja','language' => '日本語']); ?>
<?php $component->withName('language'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83)): ?>
<?php $component = $__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83; ?>
<?php unset($__componentOriginalc42c9808c3bf01021fc91c40d7fd767e12b42d83); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
    </div>
    <div class="footer__links">
        <a class="footer__links__item" href="#">
            <p><?php echo e(__('Privacy Policy')); ?></p>
        </a>
        <a class="footer__links__item" href="#">
            <p><?php echo e(__('Terms of Use')); ?></p>
        </a>
    </div>
</footer>
</html>
<?php /**PATH C:\xampp\htdocs\matteusan\resources\views/layouts/app.blade.php ENDPATH**/ ?>