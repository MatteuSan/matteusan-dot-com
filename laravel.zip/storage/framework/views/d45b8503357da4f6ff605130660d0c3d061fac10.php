<a href="<?php echo e(route('home', [$code])); ?>" class="footer__language <?php echo e(App::getLocale() == $code ? 'footer__language--active' : ''); ?>">
    <p><?php echo e($language); ?></p>
</a>
<?php /**PATH C:\xampp\htdocs\matteusan\resources\views/components/language.blade.php ENDPATH**/ ?>